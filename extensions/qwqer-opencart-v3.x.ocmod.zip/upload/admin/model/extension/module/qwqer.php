<?php

class ModelExtensionModuleQwqer extends Model
{
    const TABLE_NAME = 'qwqer_orders';

    public function __construct($registry)
    {
        parent::__construct($registry);
        $this->install();
    }

    public function addOrder($order_id, $qwqer_id, $status = 1, $store_id = 0)
    {
        $this->db->query("INSERT INTO " . DB_PREFIX . self::TABLE_NAME . " SET store_id = '" . (int)$store_id . "', order_id = '" . (int)$order_id . "', qwqer_id = '" . (int)$qwqer_id . "', status = '" . (int)$status . "', date_added = NOW()");

        return $this->db->getLastId();
    }

    public function getOrderByOrderId($order_id)
    {
        $query = $this->db->query("SELECT DISTINCT * FROM " . DB_PREFIX . self::TABLE_NAME . " WHERE order_id = '" . (int)$order_id . "'");

        return $query->row;
    }

    public function updateStatus($id, $status)
    {
        $query = $this->db->query("UPDATE " . DB_PREFIX . self::TABLE_NAME . " SET status = '" . (int)$status . "', date_modified = NOW() WHERE id = '" . (int)$id . "'");

        return $query->row;
    }

    public function install()
    {
        $this->db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . self::TABLE_NAME . "` (
          `id` int(11) NOT NULL AUTO_INCREMENT,
          `store_id` int(11) NOT NULL DEFAULT 0,
          `order_id` int(11) NOT NULL,
          `qwqer_id` int(11) NOT NULL,
          `status` int(11) NOT NULL,
          `date_added` datetime NOT NULL,
          `date_modified` datetime NOT NULL,
          PRIMARY KEY (`id`)
        ) ENGINE=MyISAM DEFAULT CHARSET=utf8;");
    }
}
