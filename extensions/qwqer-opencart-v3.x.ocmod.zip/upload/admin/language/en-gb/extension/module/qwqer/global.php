<?php

$_['text_qwqer_status'] = 'QWQER Delivery status';
$_['text_update_qwqer_status'] = 'Update QWQER Delivery status';
$_['qwqer_status_name'] = [
    1 => 'New',
    2 => 'Accept',
    4 => 'Pickup',
    8 => 'Executor done',
    16 => 'Customer done',
    32 => 'Done',
    64 => 'Canceled by customer',
    128 => 'Canceled by executor',
    256 => 'Executor offer',
    512 => 'Customer confirm',
    1024 => 'Draft',
    2048 => 'Delete',
    4096 => 'In Box',
    8192 => 'Prior waiting',
    16384 => 'Next waiting',
    32768 => 'Pre new',
    65536 => 'Pre accept',
];
