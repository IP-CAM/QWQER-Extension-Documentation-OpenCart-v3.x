<?php

class ControllerExtensionModuleQwqerPrice extends Controller
{
    public function index()
    {
        // Preload
        $this->load->language('extension/module/qwqer/modal');
        $this->load->model('extension/module/qwqer/request');
        $this->load->model('setting/setting');
        $this->load->model('sale/order');


        // Settings
        $qwqer_settings = array_merge([
            'module_qwqer_status' => false,
            'module_qwqer_login' => null,
            'module_qwqer_password' => null,
            'module_qwqer_store_addresses' => []
        ], $this->model_setting_setting->getSetting('module_qwqer') ?: []);


        // Sender data
        if (!isset($this->request->post['sender'])) {
            $this->response->setOutput(json_encode(['error' => $this->language->get('error_sender_address_empty')]));

            return;
        }
        if (!isset($qwqer_settings['module_qwqer_store_addresses'][$this->request->post['sender']])) {
            $this->response->setOutput(json_encode(['error' => $this->language->get('error_sender_address_not_found')]));

            return;
        }
        $sender = $qwqer_settings['module_qwqer_store_addresses'][$this->request->post['sender']];


        // Receiver data
        if (!isset($this->request->post['receiver'])) {
            $this->response->setOutput(json_encode(['error' => $this->language->get('error_receiver_address_empty')]));

            return;
        }
        $receiver = $this->request->post['receiver'];


        // Order info
        if (!isset($this->request->post['order_id'])) {
            $this->response->setOutput(json_encode(['error' => $this->language->get('error_order_id_not_provided')]));

            return;
        }
        $order_info = $this->model_sale_order->getOrder($this->request->post['order_id']);
        if (!$order_info) {
            $this->response->setOutput(json_encode(['error' => $this->language->get('error_order_not_exist')]));

            return;
        }


        // Sender Address field
        $sender_address = array_filter([
            $sender['address'],
            $sender['city'],
            $sender['country'],
            $sender['state'],
            $sender['region'],
            $sender['zipcode'],
        ]);


        // Receiver Address field
        $receiver_address = array_filter([
            $receiver['address'],
            $receiver['state'],
            $receiver['region'],
            $receiver['city'],
            $receiver['country'],
            $receiver['zipcode'],
        ]);


        // Login to QWQER Api
        try {
            $loginResponse = $this->model_extension_module_qwqer_request->post('/api/xr/mch/login', [
                'login' => $this->config->get('module_qwqer_login'),
                'passw' => $this->config->get('module_qwqer_password')
            ]);
        } catch (exception $exception) {
            $this->response->setOutput(json_encode(['error' => $exception->getMessage()]));

            return;
        }
        $token = $loginResponse['data']['restid'];


        // Delivery order price from QWQER Api
        try {
            $deliveryOrderPriceResponse = $this->model_extension_module_qwqer_request->post('/api/xr/mch/delivery_price', [
                'sender' => array_merge([
                    'name' => $this->config->get('config_owner'),
                    'phone' => $this->config->get('config_telephone'),
                    'contact' => $this->config->get('config_telephone'),
                    'email' => $this->config->get('config_email'),
                    'company' => $this->config->get('config_name'),
                ], $sender, [
                    'address' => implode(', ', $sender_address)
                ]),
                'receiver' => array_merge([
                    'name' => $order_info['shipping_firstname'] . ' ' . $order_info['shipping_lastname'],
                    'contact' => $order_info['telephone'],
                    'phone' => $order_info['telephone'],
                    'email' => $order_info['email'],
                    'company' => $order_info['shipping_company'],
                ], $receiver, [
                    'address' => implode(', ', $receiver_address)
                ]),
                'ordersize' => [
                    'length' => 0,
                    'width' => 0,
                    'height' => 0,
                    'weight' => 1, // @TODO improve it, just count all products weight
                    'lenunit' => 'CENTIMETER',
                    'weightunit' => 'KILOGRAM'
                ]
            ], [
                "Authorization: Bearer {$token}"
            ]);
        } catch (exception $exception) {
            $this->response->setOutput(json_encode(['error' => $exception->getMessage()]));

            return;
        }


        $this->response->setOutput(json_encode(['data' => [
            'price' => (float)$deliveryOrderPriceResponse['data']['price'],
            'currency' => $deliveryOrderPriceResponse['data']['currency'],
            'response' => $deliveryOrderPriceResponse['data']
        ]]));
    }
}
