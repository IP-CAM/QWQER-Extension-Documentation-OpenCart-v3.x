<?php

class ControllerExtensionModuleQwqerModal extends Controller
{
    private $error = [];

    public function index()
    {
        // Preload
        $this->load->language('extension/module/qwqer/modal');
        $this->load->model('setting/setting');
        $this->load->model('sale/order');


        // Settings
        $qwqer_settings = array_merge([
            'module_qwqer_status' => false,
            'module_qwqer_login' => null,
            'module_qwqer_password' => null,
            'module_qwqer_store_addresses' => []
        ], $this->model_setting_setting->getSetting('module_qwqer') ?: []);


        // Order info
        if (isset($this->request->get['order_id'])) {
            $order_info = $this->model_sale_order->getOrder($this->request->get['order_id']);
        } else {
            $this->response->setOutput($this->load->view('extension/module/qwqer/modal_error', [
                'error' => $this->language->get('error_order_id_not_provided')
            ]));

            return;
        }
        if (!$order_info) {
            $this->response->setOutput($this->load->view('extension/module/qwqer/modal_error', [
                'error' => $this->language->get('error_order_not_exist')
            ]));

            return;
        }


        // Receiver data
        $receiver = [
            // 'name' => $order_info['shipping_firstname'] . ' ' . $order_info['shipping_lastname'],
            // 'phone' => $order_info['telephone'],
            // 'email' => $order_info['email'],
            // 'company' => $order_info['shipping_company'],
            'country' => $order_info['shipping_country'],
            'countrycode2' => $order_info['shipping_iso_code_2'],
            'zipcode' => $order_info['shipping_postcode'],
            'state' => '',
            'statecode' => '',
            'city' => $order_info['shipping_city'],
            'citycode2' => '',
            'region' => $order_info['shipping_zone'],
            'regioncode2' => $order_info['shipping_zone_code'],
            'address' => $order_info['shipping_address_1'],
            'address1' => $order_info['shipping_address_2'],
            'address2' => '',
            'addressinfo' => $order_info['comment'],
        ];


        // Response
        $this->response->setOutput($this->load->view('extension/module/qwqer/modal', [
            'user_token' => $this->session->data['user_token'],
            'qwqer_settings' => $qwqer_settings,
            'receiver' => $receiver,
            'order_info' => $order_info,
        ]));
    }
}
